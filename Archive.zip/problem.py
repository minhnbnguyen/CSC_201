"""
Name(s): Chau Tran, Minh Nguyen
CSC 201
Lab7

Did you complete this lab file during the class period (yes or no)? Yes

"""

import random

class QuizProblem:
    
    OPERATION_LIST = ['+', '-', '*', '/']
    
    """
    This class represents one (randomly generated) problem for
     use in a simple arithmetic quiz.
    Each problem must be generated so that the answers are always
    positive whole numbers (ie. 0, 1, 2, 3, ...)
    
    instance variables:
    operand1 (int): number to the left of the operation symbol
    operand2 (int): number to the right of the operation symbol
    answer (int): the answer to the quiz problem
    operation (str): the symbol for the operation ('+','-','*', '/')
    """
    def __init__(self, maxRandom):
        self.operation = random.choice(QuizProblem.OPERATION_LIST)
        self.maxRandom = maxRandom
        if self.operation == '+':
            self._randomizeAddition(self.maxRandom)
        elif self.operation == '-':
            self._randomizeSubtraction(self.maxRandom)
        elif self.operation == '*':
            self._randomizeMultiplication(self.maxRandom)
        else:
            self._randomizeDivision(self.maxRandom)
     
    def _randomizeAddition(self, maxRandom):
        self.operand1 = random.randrange(self.maxRandom + 1)
        self.operand2 = random.randrange(self.maxRandom + 1)
        self.answer = self.operand1 + self.operand2
        
    def _randomizeSubtraction(self, maxRandom):
        self.operand2 = random.randrange(self.maxRandom + 1)
        self.answer = random.randrange(self.maxRandom + 1)
        self.operand1 = self.answer + self.operand2
    
    def _randomizeMultiplication(self, maxRandom):
        self.operand1 = random.randrange(self.maxRandom + 1)
        self.operand2 = random.randrange(self.maxRandom + 1)
        self.answer = self.operand1 * self.operand2
        
    def _randomizeDivision(self, maxRandom):
        self.operand2 = random.randrange(1, self.maxRandom + 1)
        self.answer = random.randrange(self.maxRandom + 1)
        self.operand1 = self.answer * self.operand2
        
    def getAnswer(self):
        return self.answer
    
    def getQuestionString(self):
        return f'{self.operand1} {self.operation} {self.operand2} = '
    
    def __str__(self):
        return f'{self.operand1} {self.operation} {self.operand2} = {self.answer}'
    
    
def main():
    prob1 = QuizProblem(1)
    print('Question: ', prob1.getQuestionString())
    print('Answer: ', prob1.getAnswer())
    print('Equation:', prob1) #printing prob1 calls the prob1.__str__() method implicitly
    print()
    
    for count in range(25):
        prob = QuizProblem(10)
        print(prob)
        
if __name__ == '__main__':
    main()
        